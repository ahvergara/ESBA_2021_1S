﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class BasePreguntados
    {

        public DataTable RecuperarTema()
        {
            Conexion unaConexion = new Conexion();
            DataTable unRegistro = new DataTable();

            unRegistro = unaConexion.LeerPorStoreProcedure("Preguntados.dbo.spRecuperarTema");
            return unRegistro;
        }

        public DataTable RecuperarPregunta(int pIdTema)
        {
            Conexion unaConexion = new Conexion();
            DataTable unRegistro = new DataTable();
            SqlParameter[] parametros = new SqlParameter[1];

            parametros[0] = unaConexion.crearParametro("@idTema", pIdTema);

            unRegistro = unaConexion.LeerPorStoreProcedure("Preguntados.dbo.spRecuperarPregunta", parametros);
            return unRegistro;
        }

        public DataTable RecuperarOpciones(int pIdPregunta)
        {
            Conexion unaConexion = new Conexion();
            DataTable unRegistro = new DataTable();
            SqlParameter[] parametros = new SqlParameter[1];

            parametros[0] = unaConexion.crearParametro("@idPregunta", pIdPregunta);
            unRegistro = unaConexion.LeerPorStoreProcedure("Preguntados.dbo.spRecuperarOpciones", parametros);
            return unRegistro;
        }

        public DataTable RecuperarUsuario(string pNombre)
        {
            Conexion unaConexion = new Conexion();
            DataTable unRegistro = new DataTable();
            SqlParameter[] parametros = new SqlParameter[1];

            parametros[0] = unaConexion.crearParametro("@nombre", pNombre);
            unRegistro = unaConexion.LeerPorStoreProcedure("Preguntados.dbo.spRecuperarUsuario", parametros);
            return unRegistro;
        }

        public int InsertarPartida(int pIdUsuario, int pPuntosJugador)
        {
            Conexion unaConexion = new Conexion();
            DataTable unRegistro = new DataTable();
            SqlParameter[] parametros = new SqlParameter[2];

            parametros[0] = unaConexion.crearParametro("@idUsuario", pIdUsuario);
            parametros[1] = unaConexion.crearParametro("@cantPuntos", pPuntosJugador);
            return unaConexion.EscribirPorStoreProcedure("Preguntados.dbo.spInsertarPartida", parametros);
        }

        public int InsertarUsuario(string pNombreUsuario, int pIdRol)
        {
            Conexion unaConexion = new Conexion();
            DataTable unRegistro = new DataTable();
            SqlParameter[] parametros = new SqlParameter[2];

            parametros[0] = unaConexion.crearParametro("@nombre", pNombreUsuario);
            parametros[1] = unaConexion.crearParametro("@idRol", pIdRol);
            return unaConexion.EscribirPorStoreProcedure("Preguntados.dbo.spInsertarUsuario", parametros);
        }

        public DataTable RecuperarRanking()
        {
            Conexion unaConexion = new Conexion();
            DataTable unaTabla = new DataTable();

            unaTabla = unaConexion.LeerPorStoreProcedure("Preguntados.dbo.spRecuperarRanking");
            return unaTabla;
        }

        public int EliminarUsuario(int pIdUsuario)
        {
            Conexion unaConexion = new Conexion();
            DataTable unRegistro = new DataTable();
            SqlParameter[] parametros = new SqlParameter[1];

            parametros[0] = unaConexion.crearParametro("@idUsuario", pIdUsuario);
            return unaConexion.EscribirPorStoreProcedure("Preguntados.dbo.spEliminarUsuario", parametros);
        }

        public DataTable RecuperarRol(int pIdRol)
        {
            Conexion unaConexion = new Conexion();
            DataTable unRegistro = new DataTable();
            SqlParameter[] parametros = new SqlParameter[1];

            parametros[0] = unaConexion.crearParametro("@idRol", pIdRol);
            unRegistro = unaConexion.LeerPorStoreProcedure("Preguntados.dbo.spRecuperarRol", parametros);
            return unRegistro;
        }

        public DataTable RecuperarIdPregunta(string pDescripcion)
        {
            Conexion unaConexion = new Conexion();
            DataTable unRegistro = new DataTable();
            SqlParameter[] parametros = new SqlParameter[1];

            parametros[0] = unaConexion.crearParametro("@descripcion", pDescripcion);
            unRegistro = unaConexion.LeerPorStoreProcedure("Preguntados.dbo.spRecuperarIdPregunta", parametros);
            return unRegistro;
        }

        public int InsertarPregunta(int pIdTema, string pDescripcion, int pIdUsuarioCreador)
        {
            Conexion unaConexion = new Conexion();
            DataTable unRegistro = new DataTable();
            SqlParameter[] parametros = new SqlParameter[3];

            parametros[0] = unaConexion.crearParametro("@idTema", pIdTema);
            parametros[1] = unaConexion.crearParametro("@descripcion", pDescripcion);
            parametros[2] = unaConexion.crearParametro("@idUsuarioCreador", pIdUsuarioCreador);
            return unaConexion.EscribirPorStoreProcedure("Preguntados.dbo.spInsertarPregunta", parametros);
        }

        public int InsertarOpcion(string pDescripcion, int pFlagCorrecta, int pIdPregunta)
        {
            Conexion unaConexion = new Conexion();
            DataTable unRegistro = new DataTable();
            SqlParameter[] parametros = new SqlParameter[3];

            parametros[0] = unaConexion.crearParametro("@descripcion", pDescripcion);
            parametros[1] = unaConexion.crearParametro("@flagCorrecta", pFlagCorrecta);
            parametros[2] = unaConexion.crearParametro("@idPregunta", pIdPregunta);
            return unaConexion.EscribirPorStoreProcedure("Preguntados.dbo.spInsertarOpcion", parametros);
        }

        public DataTable RecuperarRoles()
        {
            Conexion unaConexion = new Conexion();
            DataTable unaTabla = new DataTable();

            unaTabla = unaConexion.LeerPorStoreProcedure("Preguntados.dbo.spRecuperarRoles");
            return unaTabla;
        }

        public DataTable RecuperarTemas()
        {
            Conexion unaConexion = new Conexion();
            DataTable unaTabla = new DataTable();

            unaTabla = unaConexion.LeerPorStoreProcedure("Preguntados.dbo.spRecuperarTemas");
            return unaTabla;
        }
    }
}
