﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class Tema
    {
        private int idTema;
        private string descripcion;

        public int IdTema
        {
            get
            {
                return idTema;
            }

            set
            {
                idTema = value;
            }
        }

        public string Descripcion
        {
            get
            {
                return descripcion;
            }

            set
            {
                descripcion = value;
            }
        }

        public override string ToString()
        {
            return this.Descripcion;
        }

    }
}
