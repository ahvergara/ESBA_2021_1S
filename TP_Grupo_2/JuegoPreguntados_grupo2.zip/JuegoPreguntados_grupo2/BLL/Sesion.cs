﻿using DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class Sesion
    {
        private Usuario unUsuario;

        public Usuario UnUsuario
        {
            get
            {
                return unUsuario;
            }

            set
            {
                unUsuario = value;
            }
        }

        public bool ValidarLoggeoUsuario(string pNombreUsuario)
        {
            BasePreguntados basePreguntados = new BasePreguntados();

            DataTable unRegistroUsuario = basePreguntados.RecuperarUsuario(pNombreUsuario);

            if(unRegistroUsuario.Rows.Count > 0)
            {
                DataTable unRegistroRol = basePreguntados.RecuperarRol(int.Parse(unRegistroUsuario.Rows[0]["idRol"].ToString()));
                Rol unRol = new Rol();
                unRol.IdRol = int.Parse(unRegistroRol.Rows[0]["idRol"].ToString());
                unRol.Descripcion = unRegistroRol.Rows[0]["descripcion"].ToString();

                if(unRol.Descripcion == "Jugador")
                {
                    UnUsuario = new Jugador();
                }
                else if (unRol.Descripcion == "Administrador")
                {
                    UnUsuario = new Administrador();

                }
                else //UnRol.Descripcion == "Especial"
                {
                    UnUsuario = new Especial();
                }

                UnUsuario.UnRol = unRol;
                UnUsuario.IdUsuario = int.Parse(unRegistroUsuario.Rows[0]["idUsuario"].ToString());
                UnUsuario.Nombre = unRegistroUsuario.Rows[0]["nombre"].ToString();
                return true;
            }
            else
            {
                return false;
            }

        }

        public bool CrearUsuario(string pNombreUsuario, Rol pUnRol)
        {
            BasePreguntados basePreguntados = new BasePreguntados();
            DataTable unRegistro;

            unRegistro = basePreguntados.RecuperarUsuario(pNombreUsuario);
            if(unRegistro.Rows.Count == 0)
            {
                if(basePreguntados.InsertarUsuario(pNombreUsuario, pUnRol.IdRol) == 1)
                {
                    return true;
                }
                else
                {
                    throw new Exception("Error al intentar insertar usuario");
                }
            }
            else
            {
                return false;
            }

        }

        public bool BorrarUsuario(string pNombreUsuario)
        {
            BasePreguntados basePreguntados = new BasePreguntados();
            DataTable unRegistro;
            int idUsuario;

            unRegistro = basePreguntados.RecuperarUsuario(pNombreUsuario);
            if (unRegistro.Rows.Count > 0)
            {
                idUsuario = int.Parse(unRegistro.Rows[0]["idUsuario"].ToString());
                if (basePreguntados.EliminarUsuario(idUsuario) == 1)
                {
                    return true;
                }
                else
                {
                    throw new Exception("Error al intentar borrar usuario");
                }
            }
            else
            {
                return false;
            }

        }

        public bool CrearPregunta(Tema unTema, Pregunta unaPregunta, List<Opcion> opciones)
        {
            BasePreguntados basePreguntados = new BasePreguntados();
            DataTable unRegistro;

            int idTema = unTema.IdTema;
            string descripcion = unaPregunta.Descripcion;
            int idUsuarioCreador = unaPregunta.IdUsuarioCreador;

            if(basePreguntados.InsertarPregunta(idTema, descripcion, idUsuarioCreador) < 1)
            {
                return false;
            }
            else
            {
                unRegistro = basePreguntados.RecuperarIdPregunta(descripcion);
                if (unRegistro.Rows.Count < 1)
                {
                    return false;
                }
                else
                {
                    unaPregunta.IdPregunta = int.Parse(unRegistro.Rows[0]["idPregunta"].ToString());

                    foreach (Opcion unaOpcion in opciones)
                    {
                        descripcion = unaOpcion.Descripcion;
                        int flagCorrecta = 0;
                        if (unaOpcion.FlagCorrecta)
                            flagCorrecta = 1;
                        int idPregunta = unaPregunta.IdPregunta;

                        if (basePreguntados.InsertarOpcion(descripcion, flagCorrecta, idPregunta) < 1)
                        {
                            return false;
                        }
                    }

                    return true;
                }
            }
        }

        public List<Rol> ObtenerRoles()
        {
            List<Rol> roles = new List<Rol>();

            BasePreguntados basePreguntados = new BasePreguntados();
            DataTable registrosRol = basePreguntados.RecuperarRoles();

            for(int i = 0; i < registrosRol.Rows.Count; i++)
            {
                Rol unRol = new Rol();
                unRol.IdRol = int.Parse(registrosRol.Rows[i]["idRol"].ToString());
                unRol.Descripcion = registrosRol.Rows[i]["descripcion"].ToString();
                roles.Add(unRol);
            }

            return roles;
        }

        public List<Tema> ObtenerTemas()
        {
            List<Tema> temas = new List<Tema>();

            BasePreguntados basePreguntados = new BasePreguntados();
            DataTable registrosTema = basePreguntados.RecuperarTemas();

            for (int i = 0; i < registrosTema.Rows.Count; i++)
            {
                Tema unTema = new Tema();
                unTema.IdTema = int.Parse(registrosTema.Rows[i]["idTema"].ToString());
                unTema.Descripcion = registrosTema.Rows[i]["descripcion"].ToString();
                temas.Add(unTema);
            }

            return temas;
        }

    }
}
