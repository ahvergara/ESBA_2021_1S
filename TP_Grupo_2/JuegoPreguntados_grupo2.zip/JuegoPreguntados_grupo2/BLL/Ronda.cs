﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class Ronda
    {
        private Tema unTema;
        private Pregunta unaPregunta;
        private List<Opcion> opciones;

        public Tema UnTema
        {
            get
            {
                return unTema;
            }

            set
            {
                unTema = value;
            }
        }

        public Pregunta UnaPregunta
        {
            get
            {
                return unaPregunta;
            }

            set
            {
                unaPregunta = value;
            }
        }

        public List<Opcion> Opciones
        {
            get
            {
                return opciones;
            }

            set
            {
                opciones = value;
            }
        }

        public bool EsOpcionCorrecta(string pDescripcionOpcion)
        {
            Opcion unaOpcion = Opciones.Find(x => x.Descripcion == pDescripcionOpcion);
            return unaOpcion.FlagCorrecta;
        }
    }
}
