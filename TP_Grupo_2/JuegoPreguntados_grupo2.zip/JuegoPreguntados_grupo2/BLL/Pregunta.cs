﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class Pregunta
    {
        private int idPregunta;
        private string descripcion;
        private int idUsuarioCreador;

        public int IdPregunta
        {
            get
            {
                return idPregunta;
            }

            set
            {
                idPregunta = value;
            }
        }

        public string Descripcion
        {
            get
            {
                return descripcion;
            }

            set
            {
                descripcion = value;
            }
        }

        public int IdUsuarioCreador
        {
            get
            {
                return idUsuarioCreador;
            }

            set
            {
                idUsuarioCreador = value;
            }
        }
    }
}
