﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class Especial : Usuario
    {
        public override bool PuedeCrearPregunta()
        {
            return true;
        }

        public override bool PuedeCrearUsuario()
        {
            return false;
        }

        public override bool PuedeJugar()
        {
            return true;
        }
    }
}
