﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class Opcion
    {
        private int idOpcion;
        private string descripcion;
        private bool flagCorrecta;

        public int IdOpcion
        {
            get
            {
                return idOpcion;
            }

            set
            {
                idOpcion = value;
            }
        }

        public string Descripcion
        {
            get
            {
                return descripcion;
            }

            set
            {
                descripcion = value;
            }
        }

        public bool FlagCorrecta
        {
            get
            {
                return flagCorrecta;
            }

            set
            {
                flagCorrecta = value;
            }
        }

    }
}
