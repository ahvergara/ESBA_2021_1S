﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public abstract class Usuario
    {
        private int idUsuario;
        private Rol unRol;
        private string nombre;

        public int IdUsuario
        {
            get
            {
                return idUsuario;
            }

            set
            {
                idUsuario = value;
            }
        }

        public string Nombre
        {
            get
            {
                return nombre;
            }

            set
            {
                nombre = value;
            }
        }

        public Rol UnRol
        {
            get
            {
                return unRol;
            }

            set
            {
                unRol = value;
            }
        }

        public abstract bool PuedeCrearUsuario();
        public abstract bool PuedeCrearPregunta();
        public abstract bool PuedeJugar();
    }
}
