﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class Administrador : Usuario
    {
        public override bool PuedeCrearPregunta()
        {
            return false;
        }

        public override bool PuedeCrearUsuario()
        {
            return true;
        }

        public override bool PuedeJugar()
        {
            return false;
        }
    }
}
