﻿using DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class Preguntados
    {
        private Usuario unUsuario;
        private int puntosJugador;
        private Ronda unaRonda;
        private List<Pregunta> preguntasRespondidas;

        public Preguntados(Usuario unUsuario)
        {
            UnUsuario = unUsuario;
            PuntosJugador = 0;
            PreguntasRespondidas = new List<Pregunta>();
        }

        public List<Pregunta> PreguntasRespondidas
        {
            get
            {
                return preguntasRespondidas;
            }

            set
            {
                preguntasRespondidas = value;
            }
        }

        public Ronda UnaRonda
        {
            get
            {
                return unaRonda;
            }

            set
            {
                unaRonda = value;
            }
        }

        public int PuntosJugador
        {
            get
            {
                return puntosJugador;
            }

            set
            {
                puntosJugador = value;
            }
        }

        public Usuario UnUsuario
        {
            get
            {
                return unUsuario;
            }

            set
            {
                unUsuario = value;
            }
        }

        public Preguntados()
        {
            PreguntasRespondidas = new List<Pregunta>();
        }

        public Ronda ObtenerPregunta()
        {
            Tema unTema;
            Pregunta unaPregunta;
            List<Opcion> opciones;

            //ciclar hasta que no se repita pregunta
            do
            {
                unTema = RecuperarTema();
                unaPregunta = RecuperarPregunta(unTema.IdTema);
                opciones = RecuperarOpciones(unaPregunta.IdPregunta);
            }
            while (SeRepitePregunta(unaPregunta));

            UnaRonda = new Ronda();
            UnaRonda.UnTema = unTema;
            UnaRonda.UnaPregunta = unaPregunta;
            UnaRonda.Opciones = opciones;

            //agregar a preguntas respondidas para luego validar que no se repita
            PreguntasRespondidas.Add(unaPregunta);

            return UnaRonda;

        }

        private bool SeRepitePregunta(Pregunta unaPregunta)
        {
            if((PreguntasRespondidas == null) || (PreguntasRespondidas.Find(x => x.IdPregunta == unaPregunta.IdPregunta) == null))
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public bool ResponderPregunta(string pDescripcionOpcion)
        {
            return UnaRonda.EsOpcionCorrecta(pDescripcionOpcion);
        }

        public Tema RecuperarTema()
        {
            BasePreguntados basePreguntados = new BasePreguntados();
            Tema unTema = new Tema();

            DataTable unRegistro = basePreguntados.RecuperarTema();
            unTema.IdTema = int.Parse(unRegistro.Rows[0]["idTema"].ToString());
            unTema.Descripcion = unRegistro.Rows[0]["descripcion"].ToString();

            return unTema;
        }

        public int GuardarPartida()
        {
            BasePreguntados basePreguntados = new BasePreguntados();

            int idUsuario = UnUsuario.IdUsuario;

            return basePreguntados.InsertarPartida(idUsuario, this.PuntosJugador);
        }

        public Pregunta RecuperarPregunta(int pIdTema)
        {
            BasePreguntados basePreguntados = new BasePreguntados();
            Pregunta unaPregunta = new Pregunta();

            DataTable unRegistro = basePreguntados.RecuperarPregunta(pIdTema);
            unaPregunta.IdPregunta = int.Parse(unRegistro.Rows[0]["idPregunta"].ToString());
            unaPregunta.Descripcion = unRegistro.Rows[0]["descripcion"].ToString();

            return unaPregunta;
        }

        public List<Opcion> RecuperarOpciones(int pIdPregunta)
        {
            BasePreguntados basePreguntados = new BasePreguntados();
            List<Opcion> opciones = new List<Opcion>();

            DataTable unRegistro = basePreguntados.RecuperarOpciones(pIdPregunta);
            for(int i = 0; i < 4; i++)
            {
                Opcion unaOpcion = new Opcion();
                unaOpcion.IdOpcion = int.Parse(unRegistro.Rows[i]["idOpcion"].ToString());
                unaOpcion.Descripcion = unRegistro.Rows[i]["descripcion"].ToString();
                int flagCorrecta;
                flagCorrecta = int.Parse(unRegistro.Rows[i]["flagCorrecta"].ToString());
                if (flagCorrecta == 1)
                    unaOpcion.FlagCorrecta = true;
                else
                    unaOpcion.FlagCorrecta = false;

                opciones.Add(unaOpcion);
            }

            return opciones;
        }

        public DataTable ObtenerRanking()
        {
            BasePreguntados basePreguntados = new BasePreguntados();

            DataTable unRanking = basePreguntados.RecuperarRanking();

            return unRanking;
        }

    }
}
