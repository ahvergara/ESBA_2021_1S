﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;

namespace UI
{
    public partial class frmPreguntaRespuesta : Form
    {
        private Preguntados unJuego;
        private Usuario unUsuario;

        public frmPreguntaRespuesta()
        {
            InitializeComponent();
        }

        public Preguntados UnJuego
        {
            get
            {
                return unJuego;
            }

            set
            {
                unJuego = value;
            }
        }

        public Usuario UnUsuario
        {
            get
            {
                return unUsuario;
            }

            set
            {
                unUsuario = value;
            }
        }

        private void frmPreguntaRespuesta_Load(object sender, EventArgs e)
        {
            //Se hardcodea, luego se lo pasara el formulario principal
            //UnUsuario = new Usuario();
            //UnUsuario.IdRol = 1;
            //UnUsuario.IdUsuario = 2;
            //UnUsuario.Nombre = "Gastón";

            UnJuego = new Preguntados(UnUsuario);
            btnResponder.Enabled = true;
            btnSiguiente.Enabled = false;

            txtNombreJugador.Text = UnJuego.UnUsuario.Nombre;
            txtPuntosJugador.Text = UnJuego.PuntosJugador.ToString();

            IniciarRonda();
        }

        private void IniciarRonda()
        {
            Ronda unaRonda = unJuego.ObtenerPregunta();
            txtTema.Text = unaRonda.UnTema.Descripcion;
            txtPregunta.Text = unaRonda.UnaPregunta.Descripcion;
            txtOpcion1.Text = unaRonda.Opciones.ElementAt(0).Descripcion;
            txtOpcion2.Text = unaRonda.Opciones.ElementAt(1).Descripcion;
            txtOpcion3.Text = unaRonda.Opciones.ElementAt(2).Descripcion;
            txtOpcion4.Text = unaRonda.Opciones.ElementAt(3).Descripcion;
        }

        private void btnResponder_Click(object sender, EventArgs e)
        {
            bool esCorrecta;

            if (optOpcion1.Checked)
            {
                esCorrecta = unJuego.ResponderPregunta(txtOpcion1.Text);
            }
            else if (optOpcion2.Checked)
            {
                esCorrecta = unJuego.ResponderPregunta(txtOpcion2.Text);
            }
            else if (optOpcion3.Checked)
            {
                esCorrecta = unJuego.ResponderPregunta(txtOpcion3.Text);
            }
            else //optOpcion4.Checked
            {
                esCorrecta = unJuego.ResponderPregunta(txtOpcion4.Text);
            }

            if(esCorrecta)
            {
                MessageBox.Show("Respuesta correcta!");
                unJuego.PuntosJugador = unJuego.PuntosJugador + 1;
                txtPuntosJugador.Text = unJuego.PuntosJugador.ToString();
                btnResponder.Enabled = false;
                btnSiguiente.Enabled = true;
            }
            else
            {
                MessageBox.Show("Respuesta incorrecta... Juego finalizado. Sus puntos: " + unJuego.PuntosJugador.ToString());
                if(unJuego.GuardarPartida() > 0)
                {
                    MessageBox.Show("Partida guardada");
                }
                else
                {
                    MessageBox.Show("No se pudo guardar la partida");
                }
                btnResponder.Enabled = false;
                btnSiguiente.Enabled = false;
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSiguiente_Click(object sender, EventArgs e)
        {
            btnResponder.Enabled = true;
            btnSiguiente.Enabled = false;

            //limitar preguntas para que no entre en un loop
            if(UnJuego.PreguntasRespondidas.Count == 3)
            {
                MessageBox.Show("Parece que respondió todas las preguntas! Sus puntos: " + unJuego.PuntosJugador.ToString());
                if (unJuego.GuardarPartida() > 0)
                {
                    MessageBox.Show("Partida guardada");
                }
                else
                {
                    MessageBox.Show("No se pudo guardar la partida");
                }
                btnResponder.Enabled = false;
                btnSiguiente.Enabled = false;
            }
            else
            {
                IniciarRonda();
            }
        }
    }
}
