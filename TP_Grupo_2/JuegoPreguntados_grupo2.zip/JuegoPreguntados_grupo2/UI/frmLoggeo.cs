﻿using BLL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class frmLoggeo : Form
    {
        private Sesion unaSesion;

        public frmLoggeo()
        {
            InitializeComponent();
        }

        public Sesion UnaSesion
        {
            get
            {
                return unaSesion;
            }

            set
            {
                unaSesion = value;
            }
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            if(UnaSesion.ValidarLoggeoUsuario(txtNombreUsuario.Text) == true)
            {
                frmPrincipal unFrmPrincipal = new frmPrincipal();
                unFrmPrincipal.UnUsuario = UnaSesion.UnUsuario;
                unFrmPrincipal.Show();
            }
            else
            {
                MessageBox.Show("No está registrado");
                txtNombreUsuario.Text = null;
            }
        }

        private void frmLoggeo_Load(object sender, EventArgs e)
        {
            UnaSesion = new Sesion();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
