﻿namespace UI
{
    partial class frmPreguntaRespuesta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNombreJugador = new System.Windows.Forms.TextBox();
            this.lblNombreJugador = new System.Windows.Forms.Label();
            this.txtPuntosJugador = new System.Windows.Forms.TextBox();
            this.lblPuntosJugador = new System.Windows.Forms.Label();
            this.txtPregunta = new System.Windows.Forms.TextBox();
            this.lblPregunta = new System.Windows.Forms.Label();
            this.grpOpciones = new System.Windows.Forms.GroupBox();
            this.txtOpcion4 = new System.Windows.Forms.TextBox();
            this.txtOpcion3 = new System.Windows.Forms.TextBox();
            this.txtOpcion2 = new System.Windows.Forms.TextBox();
            this.txtOpcion1 = new System.Windows.Forms.TextBox();
            this.optOpcion4 = new System.Windows.Forms.RadioButton();
            this.optOpcion3 = new System.Windows.Forms.RadioButton();
            this.optOpcion2 = new System.Windows.Forms.RadioButton();
            this.optOpcion1 = new System.Windows.Forms.RadioButton();
            this.btnResponder = new System.Windows.Forms.Button();
            this.btnSiguiente = new System.Windows.Forms.Button();
            this.txtTema = new System.Windows.Forms.TextBox();
            this.lblTema = new System.Windows.Forms.Label();
            this.btnVolver = new System.Windows.Forms.Button();
            this.grpOpciones.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtNombreJugador
            // 
            this.txtNombreJugador.Enabled = false;
            this.txtNombreJugador.Location = new System.Drawing.Point(53, 65);
            this.txtNombreJugador.Name = "txtNombreJugador";
            this.txtNombreJugador.Size = new System.Drawing.Size(267, 20);
            this.txtNombreJugador.TabIndex = 0;
            // 
            // lblNombreJugador
            // 
            this.lblNombreJugador.AutoSize = true;
            this.lblNombreJugador.Location = new System.Drawing.Point(50, 33);
            this.lblNombreJugador.Name = "lblNombreJugador";
            this.lblNombreJugador.Size = new System.Drawing.Size(44, 13);
            this.lblNombreJugador.TabIndex = 1;
            this.lblNombreJugador.Text = "Nombre";
            // 
            // txtPuntosJugador
            // 
            this.txtPuntosJugador.Enabled = false;
            this.txtPuntosJugador.Location = new System.Drawing.Point(407, 65);
            this.txtPuntosJugador.Name = "txtPuntosJugador";
            this.txtPuntosJugador.Size = new System.Drawing.Size(227, 20);
            this.txtPuntosJugador.TabIndex = 2;
            // 
            // lblPuntosJugador
            // 
            this.lblPuntosJugador.AutoSize = true;
            this.lblPuntosJugador.Location = new System.Drawing.Point(404, 33);
            this.lblPuntosJugador.Name = "lblPuntosJugador";
            this.lblPuntosJugador.Size = new System.Drawing.Size(40, 13);
            this.lblPuntosJugador.TabIndex = 3;
            this.lblPuntosJugador.Text = "Puntos";
            // 
            // txtPregunta
            // 
            this.txtPregunta.Enabled = false;
            this.txtPregunta.Location = new System.Drawing.Point(53, 225);
            this.txtPregunta.Name = "txtPregunta";
            this.txtPregunta.Size = new System.Drawing.Size(581, 20);
            this.txtPregunta.TabIndex = 4;
            // 
            // lblPregunta
            // 
            this.lblPregunta.AutoSize = true;
            this.lblPregunta.Location = new System.Drawing.Point(53, 193);
            this.lblPregunta.Name = "lblPregunta";
            this.lblPregunta.Size = new System.Drawing.Size(50, 13);
            this.lblPregunta.TabIndex = 5;
            this.lblPregunta.Text = "Pregunta";
            // 
            // grpOpciones
            // 
            this.grpOpciones.Controls.Add(this.txtOpcion4);
            this.grpOpciones.Controls.Add(this.txtOpcion3);
            this.grpOpciones.Controls.Add(this.txtOpcion2);
            this.grpOpciones.Controls.Add(this.txtOpcion1);
            this.grpOpciones.Controls.Add(this.optOpcion4);
            this.grpOpciones.Controls.Add(this.optOpcion3);
            this.grpOpciones.Controls.Add(this.optOpcion2);
            this.grpOpciones.Controls.Add(this.optOpcion1);
            this.grpOpciones.Location = new System.Drawing.Point(56, 278);
            this.grpOpciones.Name = "grpOpciones";
            this.grpOpciones.Size = new System.Drawing.Size(601, 305);
            this.grpOpciones.TabIndex = 6;
            this.grpOpciones.TabStop = false;
            this.grpOpciones.Text = "Opciones";
            // 
            // txtOpcion4
            // 
            this.txtOpcion4.Enabled = false;
            this.txtOpcion4.Location = new System.Drawing.Point(34, 261);
            this.txtOpcion4.Name = "txtOpcion4";
            this.txtOpcion4.Size = new System.Drawing.Size(544, 20);
            this.txtOpcion4.TabIndex = 7;
            // 
            // txtOpcion3
            // 
            this.txtOpcion3.Enabled = false;
            this.txtOpcion3.Location = new System.Drawing.Point(34, 199);
            this.txtOpcion3.Name = "txtOpcion3";
            this.txtOpcion3.Size = new System.Drawing.Size(544, 20);
            this.txtOpcion3.TabIndex = 6;
            // 
            // txtOpcion2
            // 
            this.txtOpcion2.Enabled = false;
            this.txtOpcion2.Location = new System.Drawing.Point(34, 138);
            this.txtOpcion2.Name = "txtOpcion2";
            this.txtOpcion2.Size = new System.Drawing.Size(544, 20);
            this.txtOpcion2.TabIndex = 5;
            // 
            // txtOpcion1
            // 
            this.txtOpcion1.Enabled = false;
            this.txtOpcion1.Location = new System.Drawing.Point(34, 76);
            this.txtOpcion1.Name = "txtOpcion1";
            this.txtOpcion1.Size = new System.Drawing.Size(544, 20);
            this.txtOpcion1.TabIndex = 4;
            // 
            // optOpcion4
            // 
            this.optOpcion4.AutoSize = true;
            this.optOpcion4.Location = new System.Drawing.Point(34, 238);
            this.optOpcion4.Name = "optOpcion4";
            this.optOpcion4.Size = new System.Drawing.Size(68, 17);
            this.optOpcion4.TabIndex = 3;
            this.optOpcion4.TabStop = true;
            this.optOpcion4.Text = "Opcion 4";
            this.optOpcion4.UseVisualStyleBackColor = true;
            // 
            // optOpcion3
            // 
            this.optOpcion3.AutoSize = true;
            this.optOpcion3.Location = new System.Drawing.Point(34, 176);
            this.optOpcion3.Name = "optOpcion3";
            this.optOpcion3.Size = new System.Drawing.Size(68, 17);
            this.optOpcion3.TabIndex = 2;
            this.optOpcion3.TabStop = true;
            this.optOpcion3.Text = "Opcion 3";
            this.optOpcion3.UseVisualStyleBackColor = true;
            // 
            // optOpcion2
            // 
            this.optOpcion2.AutoSize = true;
            this.optOpcion2.Location = new System.Drawing.Point(34, 115);
            this.optOpcion2.Name = "optOpcion2";
            this.optOpcion2.Size = new System.Drawing.Size(68, 17);
            this.optOpcion2.TabIndex = 1;
            this.optOpcion2.TabStop = true;
            this.optOpcion2.Text = "Opcion 2";
            this.optOpcion2.UseVisualStyleBackColor = true;
            // 
            // optOpcion1
            // 
            this.optOpcion1.AutoSize = true;
            this.optOpcion1.Checked = true;
            this.optOpcion1.Location = new System.Drawing.Point(34, 53);
            this.optOpcion1.Name = "optOpcion1";
            this.optOpcion1.Size = new System.Drawing.Size(68, 17);
            this.optOpcion1.TabIndex = 0;
            this.optOpcion1.TabStop = true;
            this.optOpcion1.Text = "Opcion 1";
            this.optOpcion1.UseVisualStyleBackColor = true;
            // 
            // btnResponder
            // 
            this.btnResponder.Location = new System.Drawing.Point(710, 351);
            this.btnResponder.Name = "btnResponder";
            this.btnResponder.Size = new System.Drawing.Size(75, 23);
            this.btnResponder.TabIndex = 7;
            this.btnResponder.Text = "Responder";
            this.btnResponder.UseVisualStyleBackColor = true;
            this.btnResponder.Click += new System.EventHandler(this.btnResponder_Click);
            // 
            // btnSiguiente
            // 
            this.btnSiguiente.Location = new System.Drawing.Point(710, 454);
            this.btnSiguiente.Name = "btnSiguiente";
            this.btnSiguiente.Size = new System.Drawing.Size(75, 23);
            this.btnSiguiente.TabIndex = 8;
            this.btnSiguiente.Text = "Siguiente";
            this.btnSiguiente.UseVisualStyleBackColor = true;
            this.btnSiguiente.Click += new System.EventHandler(this.btnSiguiente_Click);
            // 
            // txtTema
            // 
            this.txtTema.Enabled = false;
            this.txtTema.Location = new System.Drawing.Point(125, 132);
            this.txtTema.Name = "txtTema";
            this.txtTema.Size = new System.Drawing.Size(414, 20);
            this.txtTema.TabIndex = 9;
            // 
            // lblTema
            // 
            this.lblTema.AutoSize = true;
            this.lblTema.Location = new System.Drawing.Point(56, 132);
            this.lblTema.Name = "lblTema";
            this.lblTema.Size = new System.Drawing.Size(34, 13);
            this.lblTema.TabIndex = 10;
            this.lblTema.Text = "Tema";
            // 
            // btnVolver
            // 
            this.btnVolver.Location = new System.Drawing.Point(710, 560);
            this.btnVolver.Name = "btnVolver";
            this.btnVolver.Size = new System.Drawing.Size(75, 23);
            this.btnVolver.TabIndex = 11;
            this.btnVolver.Text = "Volver";
            this.btnVolver.UseVisualStyleBackColor = true;
            this.btnVolver.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // frmPreguntaRespuesta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(827, 620);
            this.Controls.Add(this.btnVolver);
            this.Controls.Add(this.lblTema);
            this.Controls.Add(this.txtTema);
            this.Controls.Add(this.btnSiguiente);
            this.Controls.Add(this.btnResponder);
            this.Controls.Add(this.grpOpciones);
            this.Controls.Add(this.lblPregunta);
            this.Controls.Add(this.txtPregunta);
            this.Controls.Add(this.lblPuntosJugador);
            this.Controls.Add(this.txtPuntosJugador);
            this.Controls.Add(this.lblNombreJugador);
            this.Controls.Add(this.txtNombreJugador);
            this.Name = "frmPreguntaRespuesta";
            this.Text = "Preguntas y Respuestas";
            this.Load += new System.EventHandler(this.frmPreguntaRespuesta_Load);
            this.grpOpciones.ResumeLayout(false);
            this.grpOpciones.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNombreJugador;
        private System.Windows.Forms.Label lblNombreJugador;
        private System.Windows.Forms.TextBox txtPuntosJugador;
        private System.Windows.Forms.Label lblPuntosJugador;
        private System.Windows.Forms.TextBox txtPregunta;
        private System.Windows.Forms.Label lblPregunta;
        private System.Windows.Forms.GroupBox grpOpciones;
        private System.Windows.Forms.RadioButton optOpcion1;
        private System.Windows.Forms.RadioButton optOpcion2;
        private System.Windows.Forms.RadioButton optOpcion3;
        private System.Windows.Forms.RadioButton optOpcion4;
        private System.Windows.Forms.Button btnResponder;
        private System.Windows.Forms.Button btnSiguiente;
        private System.Windows.Forms.TextBox txtOpcion4;
        private System.Windows.Forms.TextBox txtOpcion3;
        private System.Windows.Forms.TextBox txtOpcion2;
        private System.Windows.Forms.TextBox txtOpcion1;
        private System.Windows.Forms.TextBox txtTema;
        private System.Windows.Forms.Label lblTema;
        private System.Windows.Forms.Button btnVolver;
    }
}

