﻿using BLL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class frmAltaUsuario : Form
    {
        private Sesion unaSesion;

        public frmAltaUsuario()
        {
            InitializeComponent();
            UnaSesion = new Sesion();
        }

        public Sesion UnaSesion
        {
            get
            {
                return unaSesion;
            }

            set
            {
                unaSesion = value;
            }
        }

        private void frmAltaUsuario_Load(object sender, EventArgs e)
        {
            txtNombreUsuario.Text = "";
            cmbRol.DataSource = UnaSesion.ObtenerRoles();
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCrear_Click(object sender, EventArgs e)
        {
            Rol unRol;
            string nombreUsuario;

            if(txtNombreUsuario.Text == "")
            {
                MessageBox.Show("Debe ingresar un nombre");
            }
            else
            {
                if(cmbRol.SelectedItem == null)
                {
                    MessageBox.Show("Debe ingresar un rol");
                }
                else
                {
                    nombreUsuario = txtNombreUsuario.Text;
                    unRol = (Rol)cmbRol.SelectedItem;
                    UnaSesion = new Sesion();
                    if (UnaSesion.CrearUsuario(nombreUsuario, unRol))
                    {
                        MessageBox.Show("Usuario creado");
                        txtNombreUsuario.Text = "";
                    }
                    else
                    {
                        MessageBox.Show("El usuario ya existe");
                        txtNombreUsuario.Text = "";
                    }
                }
            }
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            string nombreUsuario;

            if (txtNombreUsuario.Text == "")
            {
                MessageBox.Show("Debe ingresar un nombre");
            }
            else
            {
                nombreUsuario = txtNombreUsuario.Text;
                UnaSesion = new Sesion();
                if (UnaSesion.BorrarUsuario(nombreUsuario))
                {
                    MessageBox.Show("Usuario borrado");
                    txtNombreUsuario.Text = "";
                }
                else
                {
                    MessageBox.Show("El usuario no existe");
                    txtNombreUsuario.Text = "";
                }
            }

        }
    }
}
