﻿using BLL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class frmPrincipal : Form
    {
        private Usuario unUsuario;

        public frmPrincipal()
        {
            InitializeComponent();
        }

        public Usuario UnUsuario
        {
            get
            {
                return unUsuario;
            }

            set
            {
                unUsuario = value;
            }
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            txtNombreUsuario.Text = UnUsuario.Nombre;

            btnRanking.Visible = true;

            if (UnUsuario.PuedeJugar())
                btnJugar.Visible = true;
            else
                btnJugar.Visible = false;

            if (UnUsuario.PuedeCrearUsuario())
                btnCrearUsuario.Visible = true;
            else
                btnCrearUsuario.Visible = false;

            if (UnUsuario.PuedeCrearPregunta())
                btnCrearPregunta.Visible = true;
            else
                btnCrearPregunta.Visible = false;

        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnJugar_Click(object sender, EventArgs e)
        {
            frmPreguntaRespuesta unFrmPreguntaRespuesta = new frmPreguntaRespuesta();
            unFrmPreguntaRespuesta.UnUsuario = this.UnUsuario;
            unFrmPreguntaRespuesta.Show();
        }

        private void btnRanking_Click(object sender, EventArgs e)
        {
            frmRanking unFrmRanking = new frmRanking();
            unFrmRanking.Show();
        }

        private void btnCrearUsuario_Click(object sender, EventArgs e)
        {
            frmAltaUsuario unFrmAltaUsuario = new frmAltaUsuario();
            unFrmAltaUsuario.Show();
        }

        private void btnCrearPregunta_Click(object sender, EventArgs e)
        {
            frmAltaPregunta unFrmAltaPregunta = new frmAltaPregunta();
            unFrmAltaPregunta.UnUsuario = this.UnUsuario;
            unFrmAltaPregunta.Show();
        }
    }
}
