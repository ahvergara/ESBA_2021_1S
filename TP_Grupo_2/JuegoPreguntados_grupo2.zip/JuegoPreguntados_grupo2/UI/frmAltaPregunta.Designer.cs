﻿namespace UI
{
    partial class frmAltaPregunta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpOpciones = new System.Windows.Forms.GroupBox();
            this.txtOpcion4 = new System.Windows.Forms.TextBox();
            this.txtOpcion3 = new System.Windows.Forms.TextBox();
            this.txtOpcion2 = new System.Windows.Forms.TextBox();
            this.txtOpcion1 = new System.Windows.Forms.TextBox();
            this.optOpcion4 = new System.Windows.Forms.RadioButton();
            this.optOpcion3 = new System.Windows.Forms.RadioButton();
            this.optOpcion2 = new System.Windows.Forms.RadioButton();
            this.optOpcion1 = new System.Windows.Forms.RadioButton();
            this.lblPregunta = new System.Windows.Forms.Label();
            this.txtPregunta = new System.Windows.Forms.TextBox();
            this.btnVolver = new System.Windows.Forms.Button();
            this.lblTema = new System.Windows.Forms.Label();
            this.btnCrearPregunta = new System.Windows.Forms.Button();
            this.cmbTema = new System.Windows.Forms.ComboBox();
            this.grpOpciones.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpOpciones
            // 
            this.grpOpciones.Controls.Add(this.txtOpcion4);
            this.grpOpciones.Controls.Add(this.txtOpcion3);
            this.grpOpciones.Controls.Add(this.txtOpcion2);
            this.grpOpciones.Controls.Add(this.txtOpcion1);
            this.grpOpciones.Controls.Add(this.optOpcion4);
            this.grpOpciones.Controls.Add(this.optOpcion3);
            this.grpOpciones.Controls.Add(this.optOpcion2);
            this.grpOpciones.Controls.Add(this.optOpcion1);
            this.grpOpciones.Location = new System.Drawing.Point(54, 192);
            this.grpOpciones.Name = "grpOpciones";
            this.grpOpciones.Size = new System.Drawing.Size(601, 305);
            this.grpOpciones.TabIndex = 16;
            this.grpOpciones.TabStop = false;
            this.grpOpciones.Text = "Escribí Opciones y Seleccioná la Correcta:";
            // 
            // txtOpcion4
            // 
            this.txtOpcion4.Location = new System.Drawing.Point(34, 261);
            this.txtOpcion4.Name = "txtOpcion4";
            this.txtOpcion4.Size = new System.Drawing.Size(544, 20);
            this.txtOpcion4.TabIndex = 7;
            // 
            // txtOpcion3
            // 
            this.txtOpcion3.Location = new System.Drawing.Point(34, 199);
            this.txtOpcion3.Name = "txtOpcion3";
            this.txtOpcion3.Size = new System.Drawing.Size(544, 20);
            this.txtOpcion3.TabIndex = 6;
            // 
            // txtOpcion2
            // 
            this.txtOpcion2.Location = new System.Drawing.Point(34, 138);
            this.txtOpcion2.Name = "txtOpcion2";
            this.txtOpcion2.Size = new System.Drawing.Size(544, 20);
            this.txtOpcion2.TabIndex = 5;
            // 
            // txtOpcion1
            // 
            this.txtOpcion1.Location = new System.Drawing.Point(34, 76);
            this.txtOpcion1.Name = "txtOpcion1";
            this.txtOpcion1.Size = new System.Drawing.Size(544, 20);
            this.txtOpcion1.TabIndex = 4;
            // 
            // optOpcion4
            // 
            this.optOpcion4.AutoSize = true;
            this.optOpcion4.Location = new System.Drawing.Point(34, 238);
            this.optOpcion4.Name = "optOpcion4";
            this.optOpcion4.Size = new System.Drawing.Size(68, 17);
            this.optOpcion4.TabIndex = 3;
            this.optOpcion4.TabStop = true;
            this.optOpcion4.Text = "Opcion 4";
            this.optOpcion4.UseVisualStyleBackColor = true;
            // 
            // optOpcion3
            // 
            this.optOpcion3.AutoSize = true;
            this.optOpcion3.Location = new System.Drawing.Point(34, 176);
            this.optOpcion3.Name = "optOpcion3";
            this.optOpcion3.Size = new System.Drawing.Size(68, 17);
            this.optOpcion3.TabIndex = 2;
            this.optOpcion3.TabStop = true;
            this.optOpcion3.Text = "Opcion 3";
            this.optOpcion3.UseVisualStyleBackColor = true;
            // 
            // optOpcion2
            // 
            this.optOpcion2.AutoSize = true;
            this.optOpcion2.Location = new System.Drawing.Point(34, 115);
            this.optOpcion2.Name = "optOpcion2";
            this.optOpcion2.Size = new System.Drawing.Size(68, 17);
            this.optOpcion2.TabIndex = 1;
            this.optOpcion2.TabStop = true;
            this.optOpcion2.Text = "Opcion 2";
            this.optOpcion2.UseVisualStyleBackColor = true;
            // 
            // optOpcion1
            // 
            this.optOpcion1.AutoSize = true;
            this.optOpcion1.Checked = true;
            this.optOpcion1.Location = new System.Drawing.Point(34, 53);
            this.optOpcion1.Name = "optOpcion1";
            this.optOpcion1.Size = new System.Drawing.Size(68, 17);
            this.optOpcion1.TabIndex = 0;
            this.optOpcion1.TabStop = true;
            this.optOpcion1.Text = "Opcion 1";
            this.optOpcion1.UseVisualStyleBackColor = true;
            // 
            // lblPregunta
            // 
            this.lblPregunta.AutoSize = true;
            this.lblPregunta.Location = new System.Drawing.Point(51, 107);
            this.lblPregunta.Name = "lblPregunta";
            this.lblPregunta.Size = new System.Drawing.Size(89, 13);
            this.lblPregunta.TabIndex = 15;
            this.lblPregunta.Text = "Escribí Pregunta:";
            // 
            // txtPregunta
            // 
            this.txtPregunta.Location = new System.Drawing.Point(51, 139);
            this.txtPregunta.Name = "txtPregunta";
            this.txtPregunta.Size = new System.Drawing.Size(581, 20);
            this.txtPregunta.TabIndex = 14;
            // 
            // btnVolver
            // 
            this.btnVolver.Location = new System.Drawing.Point(708, 474);
            this.btnVolver.Name = "btnVolver";
            this.btnVolver.Size = new System.Drawing.Size(75, 23);
            this.btnVolver.TabIndex = 19;
            this.btnVolver.Text = "Volver";
            this.btnVolver.UseVisualStyleBackColor = true;
            this.btnVolver.Click += new System.EventHandler(this.btnVolver_Click);
            // 
            // lblTema
            // 
            this.lblTema.AutoSize = true;
            this.lblTema.Location = new System.Drawing.Point(54, 46);
            this.lblTema.Name = "lblTema";
            this.lblTema.Size = new System.Drawing.Size(65, 13);
            this.lblTema.TabIndex = 18;
            this.lblTema.Text = "Elegí Tema:";
            this.lblTema.Click += new System.EventHandler(this.lblTema_Click);
            // 
            // btnCrearPregunta
            // 
            this.btnCrearPregunta.Location = new System.Drawing.Point(708, 265);
            this.btnCrearPregunta.Name = "btnCrearPregunta";
            this.btnCrearPregunta.Size = new System.Drawing.Size(75, 69);
            this.btnCrearPregunta.TabIndex = 17;
            this.btnCrearPregunta.Text = "Crear Pregunta";
            this.btnCrearPregunta.UseVisualStyleBackColor = true;
            this.btnCrearPregunta.Click += new System.EventHandler(this.btnCrearPregunta_Click);
            // 
            // cmbTema
            // 
            this.cmbTema.FormattingEnabled = true;
            this.cmbTema.Location = new System.Drawing.Point(172, 43);
            this.cmbTema.Name = "cmbTema";
            this.cmbTema.Size = new System.Drawing.Size(198, 21);
            this.cmbTema.TabIndex = 20;
            // 
            // frmAltaPregunta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(848, 547);
            this.Controls.Add(this.cmbTema);
            this.Controls.Add(this.grpOpciones);
            this.Controls.Add(this.lblPregunta);
            this.Controls.Add(this.txtPregunta);
            this.Controls.Add(this.btnVolver);
            this.Controls.Add(this.lblTema);
            this.Controls.Add(this.btnCrearPregunta);
            this.Name = "frmAltaPregunta";
            this.Text = "Gestión de Preguntas";
            this.Load += new System.EventHandler(this.frmAltaPregunta_Load);
            this.grpOpciones.ResumeLayout(false);
            this.grpOpciones.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpOpciones;
        private System.Windows.Forms.TextBox txtOpcion4;
        private System.Windows.Forms.TextBox txtOpcion3;
        private System.Windows.Forms.TextBox txtOpcion2;
        private System.Windows.Forms.TextBox txtOpcion1;
        private System.Windows.Forms.RadioButton optOpcion4;
        private System.Windows.Forms.RadioButton optOpcion3;
        private System.Windows.Forms.RadioButton optOpcion2;
        private System.Windows.Forms.RadioButton optOpcion1;
        private System.Windows.Forms.Label lblPregunta;
        private System.Windows.Forms.TextBox txtPregunta;
        private System.Windows.Forms.Button btnVolver;
        private System.Windows.Forms.Label lblTema;
        private System.Windows.Forms.Button btnCrearPregunta;
        private System.Windows.Forms.ComboBox cmbTema;
    }
}