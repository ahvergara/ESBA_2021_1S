﻿using BLL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class frmAltaPregunta : Form
    {
        private Usuario unUsuario;
        private Sesion unaSesion;

        public frmAltaPregunta()
        {
            InitializeComponent();
            UnaSesion = new Sesion();
        }

        public Usuario UnUsuario
        {
            get
            {
                return unUsuario;
            }

            set
            {
                unUsuario = value;
            }
        }

        public Sesion UnaSesion
        {
            get
            {
                return unaSesion;
            }

            set
            {
                unaSesion = value;
            }
        }

        private void lblTema_Click(object sender, EventArgs e)
        {

        }

        private void frmAltaPregunta_Load(object sender, EventArgs e)
        {
            txtPregunta.Text = "";
            txtOpcion1.Text = "";
            txtOpcion2.Text = "";
            txtOpcion3.Text = "";
            txtOpcion4.Text = "";

            cmbTema.DataSource = UnaSesion.ObtenerTemas();
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCrearPregunta_Click(object sender, EventArgs e)
        {
            Tema unTema = new Tema();
            Pregunta unaPregunta = new Pregunta();
            List<Opcion> opciones = new List<Opcion>();
            Opcion unaOpcion;

            if(txtPregunta.Text == "" ||
               txtOpcion1.Text == ""  ||
               txtOpcion2.Text == ""  ||
               txtOpcion3.Text == ""  ||
               txtOpcion4.Text == "")
            {
                MessageBox.Show("Se debe completar todos los campos");
            }
            else
            {
                unTema = (Tema)cmbTema.SelectedItem;
                unaPregunta.Descripcion = txtPregunta.Text;
                unaPregunta.IdUsuarioCreador = UnUsuario.IdUsuario;

                //opcion 1
                unaOpcion = new Opcion();
                unaOpcion.Descripcion = txtOpcion1.Text;
                if (optOpcion1.Checked)
                    unaOpcion.FlagCorrecta = true;
                else
                    unaOpcion.FlagCorrecta = false;
                opciones.Add(unaOpcion);

                //opcion 2
                unaOpcion = new Opcion();
                unaOpcion.Descripcion = txtOpcion2.Text;
                if (optOpcion2.Checked)
                    unaOpcion.FlagCorrecta = true;
                else
                    unaOpcion.FlagCorrecta = false;
                opciones.Add(unaOpcion);

                //opcion 3
                unaOpcion = new Opcion();
                unaOpcion.Descripcion = txtOpcion3.Text;
                if (optOpcion3.Checked)
                    unaOpcion.FlagCorrecta = true;
                else
                    unaOpcion.FlagCorrecta = false;
                opciones.Add(unaOpcion);

                //opcion 4
                unaOpcion = new Opcion();
                unaOpcion.Descripcion = txtOpcion4.Text;
                if (optOpcion4.Checked)
                    unaOpcion.FlagCorrecta = true;
                else
                    unaOpcion.FlagCorrecta = false;
                opciones.Add(unaOpcion);

                if (UnaSesion.CrearPregunta(unTema, unaPregunta, opciones))
                {
                    MessageBox.Show("Pregunta creada");
                    txtPregunta.Text = "";
                    txtOpcion1.Text = "";
                    txtOpcion2.Text = "";
                    txtOpcion3.Text = "";
                    txtOpcion4.Text = "";
                }
                else
                    MessageBox.Show("Error al crear pregunta");
            }

        }
    }
}
